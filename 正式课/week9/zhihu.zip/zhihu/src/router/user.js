import User from '@/components/user/user.vue'
export default[
    {
        path:'/user',
        name:'user',
        component:User
    }
]