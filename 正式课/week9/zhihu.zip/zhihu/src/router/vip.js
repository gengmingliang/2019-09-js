import VIP from '@/components/vip/vip.vue'
export default[
    {
        path:'/vip',
        name:'vip',
        component:VIP
    }
]