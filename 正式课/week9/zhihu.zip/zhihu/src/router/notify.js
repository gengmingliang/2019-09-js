import Notify from '@/components/notify/notify.vue'
export default[
    {
        path:'/notify',
        name:'notify',
        component:Notify
    }
]