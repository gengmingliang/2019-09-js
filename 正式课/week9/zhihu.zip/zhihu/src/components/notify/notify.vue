<template>
    <div>
        通知
    </div>
</template>
<script>
// @ is an alias to /src
export default {
    name: 'notify',
    data() {
        return {
        
        }
    },
    components: {
        
    }
}
</script>
<style lang="less">

</style>