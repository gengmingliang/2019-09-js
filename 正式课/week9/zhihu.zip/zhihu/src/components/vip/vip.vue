<template>
    <div>
        VIP
    </div>
</template>
<script>
// @ is an alias to /src
export default {
    name: 'VIP',
    data() {
        return {
        
        }
    },
    components: {
        
    }
}
</script>
<style lang="less">

</style>