export default{
    count:0,
    loginState:false,
    hotList:[]
}