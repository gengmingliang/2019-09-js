# zhihu

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn run serve
```

### Compiles and minifies for production
```
yarn run build
```

### Run your tests
```
yarn run test
```

### Lints and fixes files
```
yarn run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


npm  i -g  @vue/cli  安装VUE脚手架  一个电脑安装一次即可

想用脚手架创建项目 ： 进入对应的文件夹
                    运行 vue  create  项目文件（英文）
                    先进入 自选模式   选择vuex   vue-router  css预处理器
                    再往后一路回车  回车完成之后  会自动进行依赖安装（吃网速）
                    装完依赖之后  进入项目  然后运行  npm run serve  （去package.json中查看）